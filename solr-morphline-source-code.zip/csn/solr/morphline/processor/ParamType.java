package csn.solr.morphline.processor;

public enum ParamType {
    STR, INT, BOOL
}